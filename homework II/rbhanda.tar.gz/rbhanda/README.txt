python main.py big.mtx 3 1 10
python main.py delauny.mtx 3 1 10